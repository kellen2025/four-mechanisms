# 铁壁二：图书馆 (Tushuguan)

> 文档管理规范，让知识井然有序

---

## 5分类体系

| 类别 | 特征 | 例子 | 变化频率 |
|------|------|------|---------| 
| **机制/** | 框架级操作流程 | 马诺防线机制 | 几乎不变 |
| **方案/** | 管理设计方案 | 多Agent方案 | 按需更新 |
| **项目/** | 对外产出 | 育儿游戏分析 | 项目周期 |
| **会议/** | 会议纪要 | 启动会纪要 | 即写即走 |
| **备份/** | 历史备份 | memory_backup | 自动生成 |

**核心分界线**：机制=框架规则，方案=当前设计，项目=给用户的产出

---

## 目录结构

```
~/.hermes/tushuguan/
├── INDEX.md                     # 多维索引
├── INDEX_LOG.md                 # 变更日志
├── 机制/                        # 铁壁四规
├── 方案/                        # 管理设计方案
├── 项目/                        # 对外项目产出
├── 会议/                        # 会议纪要
├── 备份/                        # 历史备份
└── 归档/                        # 历史完结内容
```

---

## 强制规则

1. root只允许 INDEX.md + INDEX_LOG.md + 分类文件夹
2. 每个.md文件必须含 YAML frontmatter
3. 写完文件立即更新 INDEX.md
4. status=archived 移入归档/
5. 项目完结时清理项目段

---

## YAML Frontmatter 模板

```yaml
---
title: 文档标题
created: YYYY-MM-DD
updated: YYYY-MM-DD
author: 作者
category: 分类
tags: [标签1, 标签2]
status: active
version: 1.0
---
```
